using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Server-authoritative game loop for the coin-collect mode.
/// Responsibilities:
///  Spawn coins when the session begins
///  Track remaining coins 
///  Determine winner
/// </summary>
public class GameManager : NetworkBehaviour
{
    [Header("Prefabs")]
    public GameObject coinPrefab;

    // Simple global flag consume by UI scripts.
    public static bool gameOver = false;
    public static string winnerText = "";

    // Gameplay tuning.
    [SerializeField] private int totalCoins = 100;

    // Server side runtime state.
    private int coinsRemaining;

    public override void OnNetworkSpawn()
    {
        // Only the host server should create world state.
        if (!IsServer)
        {
            return;
        }

        StartGame();
    }

    private void StartGame()
    {
        gameOver = false;
        winnerText = string.Empty;

        coinsRemaining = totalCoins;
        SpawnCoins();
    }

    private void SpawnCoins()
    {
        // Keep track of position to avoid spawning coins too close to each other.
        var usedPositions = new List<Vector3>(totalCoins);

        for (int i = 0; i < totalCoins; i++)
        {
            Vector3 spawnPos;

            // Find spot that isn't too close to previou coins.
            while (true)
            {
                spawnPos = new Vector3(Random.Range(-30, 30), 0.5f, Random.Range(-30, 30));

                bool tooClose = false;
                foreach (var p in usedPositions)
                {
                    if (Vector3.Distance(p, spawnPos) < 1.5f)
                    {
                        tooClose = true;
                        break;
                    }
                }

                if (!tooClose)
                {
                    break;
                }
            }

            usedPositions.Add(spawnPos);

            var coin = Instantiate(coinPrefab, spawnPos, Quaternion.identity);
            coin.GetComponent<NetworkObject>().Spawn();
        }
    }

    /// <summary>
    /// Called by the coin on the server when it is collected.
    /// </summary>
    public void CoinCollected()
    {
        if (!IsServer)
        {
            return;
        }

        coinsRemaining--;

        if (coinsRemaining <= 0)
        {
            EndGame();
        }
    }

    private void EndGame()
    {
        gameOver = true;

        int bestScore = -1;
        int winnerId = -1;
        bool isTie = false;

        foreach (var client in NetworkManager.Singleton.ConnectedClientsList)
        {
            var playerObj = client.PlayerObject;
            if (playerObj == null)
            {
                continue;
            }

            var playerNet = playerObj.GetComponent<PlayerNetwork>();
            if (playerNet == null)
            {
                continue;
            }

            int score = playerNet.score.Value;
            if (score > bestScore)
            {
                bestScore = score;
                winnerId = (int)client.ClientId + 1;
                isTie = false;
            }
            else if (score == bestScore)
            {
                isTie = true;
            }
        }

        winnerText = isTie ? "It's a tie!" : ("Player " + winnerId + " wins!");
        ShowEndScreenClientRpc(winnerText);
    }

    [ClientRpc]
    private void ShowEndScreenClientRpc(string text)
    {
        gameOver = true;
        winnerText = text;
    }

    /// <summary>
    /// Any player can request a restart. The server reset score, clear coins,
    /// and respawn the level state.
    /// </summary>
    [Rpc(SendTo.Server, InvokePermission = RpcInvokePermission.Everyone)]
    public void RestartGameServerRpc()
    {
        // Reset player score.
        foreach (var client in NetworkManager.Singleton.ConnectedClientsList)
        {
            var playerObj = client.PlayerObject;
            if (playerObj == null)
            {
                continue;
            }

            var playerNet = playerObj.GetComponent<PlayerNetwork>();
            if (playerNet == null)
            {
                continue;
            }

            playerNet.score.Value = 0;
        }

        // Despawn existing coins.
        foreach (var netObj in FindObjectsByType<NetworkObject>(FindObjectsSortMode.None))
        {
            if (netObj.IsSpawned && netObj.CompareTag("Coin"))
            {
                netObj.Despawn(true);
            }
        }

        StartGame();
        RestartGameClientRpc();
    }

    [ClientRpc]
    private void RestartGameClientRpc()
    {
        gameOver = false;
        winnerText = string.Empty;
    }
}
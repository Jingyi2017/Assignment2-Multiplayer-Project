using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Simple top-down camera follow.
/// This script only drive the camera for the *owning* player.
/// </summary>
public class TopDownFollowOwner : NetworkBehaviour
{
    [Tooltip("World-space offset applied to the owner's camera.")]
    public Vector3 offset = new Vector3(0, 20, 0);

    private Transform m_CameraTransform;

    public override void OnNetworkSpawn()
    {
        // Each client only control their own view.
        if (!IsOwner)
        {
            return;
        }

        var cam = Camera.main;
        if (cam == null)
        {
            return;
        }

        m_CameraTransform = cam.transform;

        // Initialize position and lock the top-down orientation.
        m_CameraTransform.position = transform.position + offset;
        m_CameraTransform.rotation = Quaternion.Euler(90f, 0f, 0f);
    }

    private void LateUpdate()
    {
        // Camera movement is client-local and only for owning player.
        if (!IsOwner || m_CameraTransform == null)
        {
            return;
        }

        m_CameraTransform.position = transform.position + offset;
    }
}
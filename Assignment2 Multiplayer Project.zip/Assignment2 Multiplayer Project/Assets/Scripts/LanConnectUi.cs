using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;

/// <summary>
/// Minimal LAN connect menu using Unity Transport.
/// Intended for quick local testing.
/// </summary>
public class LanConnectUI : MonoBehaviour
{
    [Tooltip("LAN host address to connect to when starting as a client.")]
    public string hostIP = "192.168.0.215";

    [Tooltip("UDP port used by Unity Transport.")]
    public ushort port = 7777;

    private void OnGUI()
    {
        var nm = NetworkManager.Singleton;
        if (nm == null)
        {
            return;
        }

        // Styles are created here to keep behavior identical to original script.
        GUIStyle labelStyle;
        GUIStyle textFieldStyle;
        GUIStyle buttonStyle;
        BuildStyles(out labelStyle, out textFieldStyle, out buttonStyle);

        const float boxWidth = 420f;
        const float boxHeight = 220f;
        float boxX = (Screen.width - boxWidth) * 0.5f;
        float boxY = (Screen.height - boxHeight) * 0.5f;

        bool isStopped = !nm.IsClient && !nm.IsServer;

        if (isStopped)
        {
            // Before host client starts.
            GUI.Box(new Rect(boxX, boxY, boxWidth, boxHeight), string.Empty);

            GUI.Label(
                new Rect(boxX + 20, boxY + 20, boxWidth - 40, 35),
                "Enter Host IP",
                labelStyle);

            hostIP = GUI.TextField(
                new Rect(boxX + 70, boxY + 65, 280, 35),
                hostIP,
                textFieldStyle);

            if (GUI.Button(new Rect(boxX + 60, boxY + 120, 130, 45), "Start Host", buttonStyle))
            {
                var transport = nm.GetComponent<UnityTransport>();

                // Bind to interface for hosting.
                transport.SetConnectionData("0.0.0.0", port, "0.0.0.0");
                nm.StartHost();
            }

            if (GUI.Button(new Rect(boxX + 230, boxY + 120, 130, 45), "Start Client", buttonStyle))
            {
                var transport = nm.GetComponent<UnityTransport>();
                transport.SetConnectionData(hostIP, port);
                nm.StartClient();
            }

            if (GUI.Button(new Rect(boxX + 145, boxY + 175, 130, 35), "Exit Game", buttonStyle))
            {
                QuitGame();
            }
        }
        else
        {
            // During gameplay.
            if (GUI.Button(new Rect(Screen.width - 150, 20, 120, 40), "Exit Game", buttonStyle))
            {
                QuitGame();
            }
        }
    }

    private static void BuildStyles(out GUIStyle labelStyle, out GUIStyle textFieldStyle, out GUIStyle buttonStyle)
    {
        labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 24,
            alignment = TextAnchor.MiddleCenter,
        };
        labelStyle.normal.textColor = Color.white;

        textFieldStyle = new GUIStyle(GUI.skin.textField)
        {
            fontSize = 22,
            alignment = TextAnchor.MiddleCenter,
        };

        buttonStyle = new GUIStyle(GUI.skin.button)
        {
            fontSize = 22,
        };
    }

    private void QuitGame()
    {
        if (NetworkManager.Singleton != null)
        {
            NetworkManager.Singleton.Shutdown();
        }

        Application.Quit();

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }
}